name = "modTemplate"
description = "modTemplate"
author = "mj"
version = "test"

api_version = 6

-- Compatibility
dont_starve_compatible = true
reign_of_giants_compatible = true
-- shipwrecked_compatible = true

icon_atlas = "modicon.xml"
icon = "modicon.tex"

configuration_options =
{
	{
		name = "Language",
		label = "Language",
		options =	{
						{description = "English", data = "EN"},
						{description = "Chinese", data = "CN"}
					},

		default = "EN",
	
	}
}