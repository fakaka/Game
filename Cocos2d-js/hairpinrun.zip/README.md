# Cocos2d-JS Project
* ## 发卡快跑

官方的demo稍加改变

## 使用方式

你需要将这些文件放到一个本地服务器或在线服务器并通过服务器访问才可以看到正确的结果。

## 帮助链接

- [在线API reference](http://www.cocos2d-x.org/reference/html5-js/V3.0/index.html)
- [下载API Reference](http://www.cocos2d-x.org/filedown/Cocos2d-JS-v3.0-API.zip)
- [文档目录](http://cocos2d-x.org/docs/manual/framework/html5/en)
- [Github仓库](https://github.com/cocos2d/cocos2d-js)
- [在线论坛](http://www.cocoachina.com/bbs/thread.php?fid=59)

=========================
# English Version
## usage

You need to host these files on a web server or local web server to see the result.

## Useful links

- [Online API reference](http://www.cocos2d-x.org/reference/html5-js/V3.0/index.html)
- [Downloadable API Reference](http://www.cocos2d-x.org/filedown/Cocos2d-JS-v3.0-API.zip)
- [Document root](http://cocos2d-x.org/docs/manual/framework/html5/en)
- [Github repository](https://github.com/cocos2d/cocos2d-js)
- [Online forum](http://discuss.cocos2d-x.org/category/javascript)